const shopId = "89359515946"; //ri mobile app builder

// const graphQlServiceUri = 'http://192.168.86.3:4000/';
const graphQlServiceUri =
    'https://fw24qgn24h.execute-api.ap-south-1.amazonaws.com/qa/';
const judgemeServieceUrl = 'https://judge.me/api/v1/reviews';
