class Sample {
  int testMethod() {
    return 1;
  }
}
