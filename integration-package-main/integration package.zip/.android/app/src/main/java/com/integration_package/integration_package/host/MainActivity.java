package com.integration_package.integration_package.host;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
