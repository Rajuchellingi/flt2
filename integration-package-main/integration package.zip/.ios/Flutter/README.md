This directory contains support code for embedding the Flutter project in an iOS app.
It should not be edited or checked in.
